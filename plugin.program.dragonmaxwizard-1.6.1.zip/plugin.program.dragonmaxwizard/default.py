import xbmcgui
xbmcgui.Dialog().ok('DragonMax RD Wizard', 'DragonMax RD Wizard installed successfully.', 'Use this starter wizard for legal build setup, themes, maintenance, and account setup guides.')
